PassMark imageUSB V1.1
Copyright (C) 2011 PassMark Software
All Rights Reserved
http://www.passmark.com 


Overview
========
ImageUSB is a free utility which lets you write an image concurrently to
multiple USB Flash Drives. Capable of creating exact bit-level copies of
USB Flash Drive (UFDs), ImageUSB is an extremely effective tool for the mass
duplication of UFDs. Unlike other USB duplication tools, ImageUSB can
preserve all unused and slack space during the cloning process, including
the Master Boot Record (MBR). ImageUSB can perform flawless mass duplications
of all UFD images, including bootable UFDs. 

Note: imageUSB is currently only able to handle images (.bin) files that were
created by imageUSB.  

Running this software to write an image file will destroy any data on any
removable drive volume specified.

To install imageUSB
===================
Copy the imageUSB directory to the Program Files directory.


To uninstall imageUSB
=====================
Delete the directory to the Program Files directory.


Requirements
============
- Operating System: XP, Vista, Windows 7 
- RAM: 256 Meg 
- Disk space: 2MB free hard disk space, plus any additional space required to store image file.


Usage
=====
1) Before starting: Backup the USB Flash Drive contents to a hard disk drive.
   This process will overwrite the USB drive selected, so remove any other 
   removable drives on the system to reduce the likelihood of mistakes.
2) This program requires Adminstration Privileges..
3) Follow the instructions on screen or in the Help documentation provided.
   Be very careful to select the correct drive letter!!!

Version History
===============
Here is a summary of all changes that have been made in each version of 
imageUSB.

Release 1.1.1010
WIN32 release 22 October 2012
-Fixed a program crash when reading fake USB drives. It seems that some USB flash drives are tricking the Windows API to incorrectly recognizing the end of the drive.

Release 1.1.1009
WIN32 release 9 July 2012
-Allows writing images larger than destination drives. End of the image will be truncated and not be written to the drive.

Release 1.1.1008
WIN32 release 19 January 2012
-Added a delay on retry for failed write attempts. Will wait 1 sec before retry.
-Address an issue where writing image would sometimes fail with Error 5: Access is Denied.

Release 1.1.1007
WIN32 release 16 November 2011
-Fixed some erroneous debug logging messages.
-Tweaked verification settings, should report which offset verification failed at.
-For Writing to flash drive, upon write failure, imageUSB will retry up to 3 times to rewrite to the failed location.

Release 1.1.1006
WIN32 release 6 October 2011
-Improved debug logging. 

Release 1.1.1005
WIN32 release 6 July 2011
- Added the ability to write .ISO to USB drives. The drive must be bigger than the iso and the drive size will
  be truncated to the size of the iso. To recover lost storage, use Window's Disk Management tool.

Release 1.1.1004
WIN32 release 25 January 2011
- Fixed an issue that would occur if more than one drives are being processed at once (happened sporadically).
- Added "-d" command line option that will log additional debug info
- Fixed typos

Release 1.1.1003 
WIN32 release 22 December 2010
- Notification/prompt when imaging finishes.
- Option for post image verification for both creating from and writing from usb drives.
  Previously, writing to drives always was verified. Verification may double the imaging
  time.
- Each image created with imageUSB will have an accompanying log file written with checksum
  values calculated during the creation process.
- MD5 & SHA1 checksum calculation implemented
- Now with more warning prompts! To prevent accidently destroying data.
- Simultaneous image creation is now supported. See the help documentation for naming
  convention used.
- Running imageUSB with -l command line will save a log (The same one as seen at the bottom of the GUI).

Release 1.1.1002 
WIN32 release 15 December 2010
- Fixed issue with overall progress bar not updating for subsequent writes after aborting.
- Cosmetic / UI changes/fixes
- Signed Executable

Release 1.1.1001 
WIN32 release 8 December 2010
- Concurrent image writing to UFD.
- Asthetics Changes.

Release 1.1.1000 
WIN32 release  1 December 2010
- GUI version.

Release 1.0.1001
WIN32 release 23 July 2010
- The USB Flash Drive data is now verified.

Release 1.0.1000 
WIN32 release 17 June 2010
- First version.


Support
=======
For technical support, questions, suggestions, please check the help file for 
our email address or visit our web page at http://www.passmark.com


Enjoy..
The PassMark Development team
